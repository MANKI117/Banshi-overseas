BANSHI OVERSEAS PREMIUM WEBSITE
===============================
Files:
- index.html
- style.css

Features:
- Premium black/gold design
- Responsive mobile layout
- Animated reveal effects
- Destination cards with photo backgrounds
- Services, visa guide and testimonials
- Free consultation form
- WhatsApp enquiry integration
- Floating WhatsApp/call/meeting/enquiry controls
- Chat popup

Contact already configured:
Phone: 96242 67665
Email: banshioverseas35@gmail.com

To publish:
1. Create a public GitHub repository named banshi-overseas.
2. Upload index.html and style.css to the repository root.
3. Settings > Pages > Deploy from branch > main > /(root) > Save.
4. Your public URL will be:
   https://YOUR-USERNAME.github.io/banshi-overseas/

Photo note:
The destination images currently use public Unsplash image URLs. For a permanent branded site, replace them with your own licensed university/country photos.
